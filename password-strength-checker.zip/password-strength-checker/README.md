# Password Strength Checker 

A Pen created on CodePen.

Original URL: [https://codepen.io/Ondela-Citywayo/pen/KwdPdLv](https://codepen.io/Ondela-Citywayo/pen/KwdPdLv).

