document.addEventListener('DOMContentLoaded', () => {
    // --- DOM Elements ---
    const passwordInput = document.getElementById('passwordInput');
    const togglePassword = document.getElementById('togglePassword');
    const eyeIconOpen = document.getElementById('eyeIconOpen');
    const eyeIconClosed = document.getElementById('eyeIconClosed');
    const strengthText = document.getElementById('strengthText');
    const progressBar = document.getElementById('progressBar');
    const feedbackText = document.getElementById('feedbackText');
    const criteriaList = document.getElementById('criteriaList');
    const darkModeToggle = document.getElementById('darkModeToggle');
    const sunIcon = document.getElementById('sunIcon');
    const moonIcon = document.getElementById('moonIcon');
    const html = document.documentElement;

    // --- Common Weak Passwords ---
    // A small list for demonstration purposes. In a real application, this would be much larger.
    const commonPasswords = new Set([
        '123456', 'password', '123456789', '12345678', '12345', '111111', '1234567', 'qwerty',
        '123123', '987654321', 'password123', 'p@ssword', 'admin', 'test', 'secret'
    ]);

    // --- Password Evaluation Logic ---
    const checkPasswordStrength = () => {
        const password = passwordInput.value;
        let score = 0;
        const feedback = [];
        const criteria = {
            length: { met: false, text: "At least 8 characters long" },
            lowercase: { met: false, text: "Contains lowercase letters (a-z)" },
            uppercase: { met: false, text: "Contains uppercase letters (A-Z)" },
            number: { met: false, text: "Contains numbers (0-9)" },
            special: { met: false, text: "Contains special characters (!@#...)" },
            notCommon: { met: false, text: "Is not a common password" }
        };

        if (password.length === 0) {
            resetUI();
            return;
        }

        // 1. Length Check
        if (password.length >= 8) {
            score += 25;
            criteria.length.met = true;
        }
        if (password.length >= 12) {
            score += 15; // Extra bonus for longer passwords
        }

        // 2. Character Type Checks
        const hasLowercase = /[a-z]/.test(password);
        if (hasLowercase) {
            score += 15;
            criteria.lowercase.met = true;
        }

        const hasUppercase = /[A-Z]/.test(password);
        if (hasUppercase) {
            score += 15;
            criteria.uppercase.met = true;
        }

        const hasNumber = /[0-9]/.test(password);
        if (hasNumber) {
            score += 15;
            criteria.number.met = true;
        }

        const hasSpecial = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password);
        if (hasSpecial) {
            score += 20;
            criteria.special.met = true;
        }
        
        // 3. Common Password Check
        if (!commonPasswords.has(password.toLowerCase())) {
            score += 10;
            criteria.notCommon.met = true;
        } else {
            score = Math.min(score, 20); // Penalize heavily for common passwords
            feedback.push("This is a very common and weak password. Please choose something more unique.");
        }

        // 4. Repetition/Pattern Check (simple version)
        if (/(.)\1{2,}/.test(password)) { // e.g., 'aaa'
            score -= 10;
            feedback.push("Avoid repeating characters.");
        }
        if (/(abc|bcd|cde|def|efg|fgh|pqr|qrs|rst|stu|tuv|uvw|vwx|wxy|xyz)/.test(password.toLowerCase())) { // e.g., 'abc'
            score -= 10;
            feedback.push("Avoid simple sequential patterns.");
        }

        score = Math.max(0, Math.min(100, score)); // Clamp score between 0 and 100

        updateUI(score, criteria, feedback);
    };

    // --- UI Update Logic ---
    const updateUI = (score, criteria, customFeedback) => {
        // Update Progress Bar and Text
        let strengthLabel = 'Weak';
        let progressBarColor = 'bg-red-500';

        if (score >= 80) {
            strengthLabel = 'Very Strong';
            progressBarColor = 'bg-green-500';
        } else if (score >= 60) {
            strengthLabel = 'Strong';
            progressBarColor = 'bg-blue-500';
        } else if (score >= 40) {
            strengthLabel = 'Medium';
            progressBarColor = 'bg-yellow-500';
        }
        
        strengthText.textContent = strengthLabel;
        progressBar.style.width = `${score}%`;
        progressBar.className = `h-2.5 rounded-full transition-all duration-300 ${progressBarColor}`;

        // Update Feedback Text
        if (customFeedback.length > 0) {
            feedbackText.textContent = customFeedback.join(' ');
        } else if (score < 100) {
            feedbackText.textContent = "Good, but you can make it even stronger.";
        } else {
            feedbackText.textContent = "Excellent! This is a very strong password.";
        }

        // Update Criteria List
        criteriaList.innerHTML = '';
        for (const key in criteria) {
            const item = criteria[key];
            const li = document.createElement('li');
            li.className = 'flex items-center strength-check-item';
            const iconColor = item.met ? 'text-green-500' : 'text-gray-400 dark:text-gray-500';
            const icon = item.met 
                ? `<svg class="w-5 h-5 mr-2 ${iconColor}" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path></svg>`
                : `<svg class="w-5 h-5 mr-2 ${iconColor}" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"></path></svg>`;
            
            li.innerHTML = `${icon} <span class="${item.met ? 'text-gray-800 dark:text-gray-200' : 'text-gray-500 dark:text-gray-400'}">${item.text}</span>`;
            criteriaList.appendChild(li);
        }
    };

    const resetUI = () => {
        strengthText.textContent = '';
        progressBar.style.width = '0%';
        progressBar.className = 'h-2.5 rounded-full transition-all duration-300';
        feedbackText.textContent = 'Enter a password to get started.';
        criteriaList.innerHTML = '';
    };

    // --- Event Listeners ---
    passwordInput.addEventListener('input', checkPasswordStrength);

    togglePassword.addEventListener('click', () => {
        const isPassword = passwordInput.type === 'password';
        passwordInput.type = isPassword ? 'text' : 'password';
        eyeIconOpen.classList.toggle('hidden', isPassword);
        eyeIconClosed.classList.toggle('hidden', !isPassword);
    });

    // --- Dark Mode Logic ---
    const applyTheme = (isDark) => {
        if (isDark) {
            html.classList.add('dark');
            moonIcon.classList.remove('hidden');
            sunIcon.classList.add('hidden');
        } else {
            html.classList.remove('dark');
            moonIcon.classList.add('hidden');
            sunIcon.classList.remove('hidden');
        }
    };

    darkModeToggle.addEventListener('click', () => {
        const isDark = html.classList.toggle('dark');
        localStorage.setItem('darkMode', isDark);
        applyTheme(isDark);
    });

    // --- Initial Setup ---
    const savedTheme = localStorage.getItem('darkMode') === 'true';
    applyTheme(savedTheme);
    resetUI();
});
